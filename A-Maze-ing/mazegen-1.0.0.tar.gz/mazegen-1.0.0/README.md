# A-Maze-ing

*This project has been created as part of the 42 curriculum by [Your Name].*

---

## Description

**A-Maze-ing** is a Python maze generator that reads a configuration file,
produces a randomly-generated maze, displays it in the terminal with ANSI
colours and interactive controls, and writes the result to a file using a
hexadecimal wall encoding.

Key features:

- Two generation algorithms: **recursive backtracker** (depth-first search)
  and **randomised Prim's**.
- Optional **perfect maze** mode — exactly one path between any two cells.
- A visible **"42" pixel-art pattern** embedded in every generated maze.
- **BFS shortest-path solver** — the solution path is shown interactively
  and written to the output file.
- A standalone **`mazegen` package** that can be installed with pip and
  reused in other projects.
- Full **reproducibility** via an optional integer seed.
- **Interactive terminal UI** — re-generate, show/hide path, cycle colour
  themes, highlight the 42 pattern, all without restarting the program.

---

## Instructions

### Requirements

- Python 3.10 or later
- `flake8` and `mypy` (for linting; installed by `make install`)

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/a-maze-ing.git
cd a-maze-ing

# (Recommended) create a virtual environment
python3 -m venv .venv && source .venv/bin/activate

# Install dependencies
make install
```

### Running

```bash
make run
# or directly:
python3 a_maze_ing.py config.txt
```

### Interactive controls (terminal)

| Key | Action |
|-----|--------|
| `r` | Re-generate with a new random seed |
| `p` | Toggle solution path overlay |
| `c` | Cycle through colour themes (4 themes) |
| `h` | Toggle '42' pattern highlight |
| `q` | Quit |

### Linting

```bash
make lint          # flake8 + mypy standard
make lint-strict   # flake8 + mypy --strict
```

### Cleanup

```bash
make clean
```

---

## Configuration file format

The configuration file uses `KEY=VALUE` pairs, one per line.
Lines starting with `#` are treated as comments and ignored.

| Key | Required | Type | Description | Example |
|-----|----------|------|-------------|---------|
| `WIDTH` | ✓ | int ≥ 2 | Number of columns | `WIDTH=20` |
| `HEIGHT` | ✓ | int ≥ 2 | Number of rows | `HEIGHT=15` |
| `ENTRY` | ✓ | x,y | Entry cell (0-based) | `ENTRY=0,0` |
| `EXIT` | ✓ | x,y | Exit cell (must differ from ENTRY) | `EXIT=19,14` |
| `OUTPUT_FILE` | ✓ | path | Destination hex file | `OUTPUT_FILE=maze.txt` |
| `PERFECT` | ✓ | bool | `True` = single path only | `PERFECT=True` |
| `SEED` | optional | int | Reproducibility seed | `SEED=42` |
| `ALGORITHM` | optional | string | `recursive_backtracker` or `prim` | `ALGORITHM=prim` |
| `ANIMATE` | optional | bool | Show step-by-step animation | `ANIMATE=False` |

**Default config (`config.txt`):**

```ini
WIDTH=20
HEIGHT=15
ENTRY=0,0
EXIT=19,14
OUTPUT_FILE=maze.txt
PERFECT=True
# SEED=42
# ALGORITHM=recursive_backtracker
# ANIMATE=False
```

### Output file format

```
<hex row 0>          ← one hex digit per cell, 0–F
<hex row 1>
...
<hex row HEIGHT-1>
                     ← empty line
entry_x,entry_y
exit_x,exit_y
<path string>        ← sequence of N/E/S/W characters (shortest path)
```

Wall encoding (4-bit per cell, bit set = wall **closed**):

| Bit | Direction |
|-----|-----------|
| 0 (LSB) | North |
| 1 | East |
| 2 | South |
| 3 | West |

Example: `A` = `0b1010` → East and West walls closed; North and South open.

---

## Maze generation algorithm

### Recursive Backtracker (default)

An iterative depth-first search implemented with an explicit stack:

1. Start at the entry cell; mark it visited.
2. Pick a random unvisited neighbour, carve the shared wall, push the new
   cell.
3. If no unvisited neighbours exist, pop the stack and backtrack.
4. Repeat until the stack is empty — every cell has been visited exactly once.

**Why this algorithm?**

- Produces long, winding corridors with relatively few dead ends —
  visually interesting mazes.
- Trivially guarantees perfect-maze property (the result is a spanning tree).
- The iterative version avoids Python's recursion limit on large grids.
- Easy to animate step-by-step.
- O(n) time and space where n = number of cells.

### Randomised Prim (bonus algorithm)

Builds the spanning tree by maintaining a frontier list of candidate walls
and picking one at random at each step.  Produces mazes with more uniform
branching and shorter average dead ends compared to the backtracker.

---

## Reusable module (`mazegen`)

The `mazegen` module can be installed independently and imported in any
Python 3.10+ project.

### Install from the package file

```bash
pip install mazegen-1.0.0-py3-none-any.whl
# or
pip install mazegen-1.0.0.tar.gz
```

### Rebuild the package from source

```bash
python3 -m pip install build
python3 -m build          # produces dist/mazegen-*.whl and dist/mazegen-*.tar.gz
```

### Basic usage

```python
from mazegen import MazeGenerator

# Instantiate
mg = MazeGenerator(
    width=20,
    height=15,
    entry=(0, 0),
    exit_=(19, 14),
    perfect=True,   # spanning-tree maze
    seed=42,        # reproducible; omit for random
)

# Generate
mg.generate(algorithm="recursive_backtracker")  # or "prim"

# Solve — returns list of 'N','E','S','W' strings
path = mg.solve()
print(f"Shortest path: {len(path)} steps")

# ASCII display with path overlay and '42' highlight
mg.display_ascii(path=path, highlight_42=True)

# Write hex file
mg.to_hex_file("maze.txt", path=path)
```

### Accessing the maze structure

```python
# mg.maze is List[List[int]], shape [height][width]
# Each cell is a 4-bit int: bit set = wall CLOSED
cell_value = mg.maze[y][x]

# Wall constants
mg.WALL_N  # 1  — North
mg.WALL_E  # 2  — East
mg.WALL_S  # 4  — South
mg.WALL_W  # 8  — West

# Check if North wall of cell (3, 2) is open:
open_north = not (mg.maze[2][3] & mg.WALL_N)

# Full connectivity check
reachable = mg._reachable_cells()   # set of (x, y) tuples
assert len(reachable) == mg.width * mg.height - len(mg._get_42_cells())
```

### Custom parameters summary

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `width` | `int` | — | Maze columns (≥ 2) |
| `height` | `int` | — | Maze rows (≥ 2) |
| `entry` | `Tuple[int,int]` | — | Entry cell (x, y) |
| `exit_` | `Tuple[int,int]` | — | Exit cell (x, y) |
| `perfect` | `bool` | `True` | Spanning-tree maze |
| `seed` | `Optional[int]` | `None` | RNG seed |

---

## Resources

### Documentation & references

- [Maze generation algorithms — Wikipedia](https://en.wikipedia.org/wiki/Maze_generation_algorithm)
- [Jamis Buck — Maze Algorithms (blog series)](http://weblog.jamisbuck.org/2011/2/7/maze-generation-algorithm-recap)
- [Python `random` module](https://docs.python.org/3/library/random.html)
- [Python `collections.deque`](https://docs.python.org/3/library/collections.html#collections.deque)
- [PEP 526 — Variable annotations](https://peps.python.org/pep-0526/)
- [PEP 257 — Docstring conventions](https://peps.python.org/pep-0257/)
- [mypy documentation](https://mypy.readthedocs.io/)
- [flake8 documentation](https://flake8.pycqa.org/)
- [Python packaging guide](https://packaging.python.org/en/latest/tutorials/packaging-projects/)

### AI usage

Claude (claude.ai) was used to:
- Review initial code structure and identify the wall-coherence / connectivity
  bug introduced by naïve `_insert_42_pattern` logic, and design the
  `_repair_connectivity` BFS fix.
- Draft and refine docstrings to PEP 257 / Google style.
- Review the interactive terminal loop for edge-case error handling.
- Draft this README template and the pyproject.toml packaging configuration.

All algorithmic logic, data-structure choices, and final code were written
and verified by the project team.

---

## Team and project management

### Team members and roles

| Member | Role |
|--------|------|
| [Name 1] | Maze generation algorithms, mazegen module, packaging |
| [Name 2] | Main entry point, config parser, interactive terminal UI |

### Planning

**Anticipated plan:**

1. Days 1–2: Research algorithms, define module API and file format.
2. Days 3–4: Implement `MazeGenerator` with backtracker + Prim.
3. Day 5: Solver (BFS), ASCII display, output file.
4. Day 6: Interactive UI, colour themes.
5. Day 7: Packaging (`pyproject.toml`, build), linting, README.

**How it evolved:**

The '42' pattern insertion proved more complex than expected — naïvely
closing all four walls and updating neighbours broke connectivity and
returned empty solver paths.  We added `_repair_connectivity` (an
iterative BFS reconnection step) which cost roughly half a day but led to
a cleaner and more robust design.

### What worked well

- Iterative backtracker — no recursion-limit issues on large grids.
- BFS solver is fast and easy to validate by walking the path manually.
- Separating `mazegen.py` as a standalone module from the start made
  packaging straightforward.

### What could be improved

- A graphical display (MiniLibX / pygame) would make animation smoother.
- The `_repair_connectivity` loop could be replaced by a smarter pattern
  placement algorithm that avoids disconnections in the first place.
- Adding a `validate_output` script would make Moulinette testing easier.

### Tools used

- **Python 3.12** — primary language.
- **mypy + flake8** — static type checking and style enforcement.
- **pytest** — unit test framework (tests not submitted).
- **build** — Python packaging (`pyproject.toml`-based).
- **Claude (claude.ai)** — code review and documentation assistance.
- **Git** — version control.
